#ifndef INC_ERA_STM32_WIZ_HPP_
#define INC_ERA_STM32_WIZ_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleStm32Wiz.hpp>

#endif /* INC_ERA_STM32_WIZ_HPP_ */
