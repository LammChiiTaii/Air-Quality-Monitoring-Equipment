#ifndef INC_ERA_ARDUINO_GSM_HPP_
#define INC_ERA_ARDUINO_GSM_HPP_

#define ERA_MODBUS

#include <ERaSimpleArduinoGsm.hpp>

#endif /* INC_ERA_ARDUINO_GSM_HPP_ */
