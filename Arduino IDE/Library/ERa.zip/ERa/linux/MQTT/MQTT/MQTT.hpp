#ifndef INC_MQTT_HPP_
#define INC_MQTT_HPP_

#include "MQTTLinux.hpp"

#endif /* INC_MQTT_HPP_ */