# BH1750 / BH1750FVI
Digital Light Sensor


Very easy to use driver for the BH1750 / BH1750FVI Digital Light Sensor.
The included examples shows how to use and connect the BH1750FVI to a NodeMCU ESP8266, Arduino UNO and Arduino DUE.


For Arduino IDE users:

Use the Library Manager to install this library.

Or download as .ZIP and add as .ZIP library (Sketch->Include Library->Add .ZIP Library).


Any questions, bugs or feature requests? Please open an issue!
